# v0.2.0 — Compatibilidad TypeScript de Identity

Durante el gate real de `v0.2.0` se detectaron diferencias de tipos con las
versiones utilizadas por iRec.

## otplib 13

`verify()` devuelve un resultado que puede ser válido o inválido. `timeStep`
solo existe en el resultado TOTP válido. Antes de persistir `lastTimeStep`,
iRec realiza narrowing estructural con:

```ts
result.valid && 'timeStep' in result
```

Se conserva `afterTimeStep` para impedir la reutilización de un código TOTP ya
aceptado.

## jose 6

`importPKCS8()` e `importSPKI()` ya no requieren el antiguo tipo público
`KeyLike`. iRec deriva el tipo directamente mediante `ReturnType`, evitando
acoplamiento a tipos eliminados de la API pública.

## ioredis 6

La integración TypeScript usa el export nombrado:

```ts
import { Redis } from 'ioredis';
```

## PostgreSQL local

El puerto oficial del host para iRec es `15432`, mapeado al `5432` interno del
contenedor `irec-postgres`.

```text
127.0.0.1:15432 -> irec-postgres:5432
```
